import {
  collection,
  doc,
  addDoc,
  updateDoc,
  getDocs,
  getDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  arrayUnion,
  arrayRemove,
  Timestamp,
} from "firebase/firestore"
import { db } from "./firebase"

// Company interface
export interface Company {
  id: string
  name: string
  position: string
  location: string
  address: string
  email: string
  website: string
  description: string
  field: string
  logo: string
  employees: string
  openPositions: number
  requirements: string[]
  benefits: string[]
  applicationDeadline: string
  coordinates: {
    latitude: number
    longitude: number
  }
  createdAt: Timestamp
  updatedAt: Timestamp
}

// User Profile interface
export interface UserProfile {
  uid: string
  email: string
  fullName: string
  fieldOfStudy: string
  university?: string
  location?: string
  coordinates?: {
    latitude: number
    longitude: number
  }
  profilePictureUrl?: string
  bookmarkedCompanies: string[]
  applications: string[]
  preferences: {
    preferredLocations: string[]
    preferredFields: string[]
    notificationsEnabled: boolean
    locationEnabled: boolean
  }
  createdAt: Timestamp
  updatedAt: Timestamp
}

// Application interface
export interface Application {
  id: string
  userId: string
  companyId: string
  companyName: string
  position: string
  status: "applied" | "in-review" | "interview" | "accepted" | "rejected" | "withdrawn"
  appliedDate: Timestamp
  lastUpdated: Timestamp
  notes?: string
  documents?: string[]
}

// Companies Database Functions
export const companiesDB = {
  // Get all companies
  async getAll(): Promise<Company[]> {
    try {
      const querySnapshot = await getDocs(collection(db, "companies"))
      return querySnapshot.docs.map(
        (doc) =>
          ({
            id: doc.id,
            ...doc.data(),
          }) as Company,
      )
    } catch (error) {
      console.error("Error fetching companies:", error)
      throw error
    }
  },

  // Get companies by field
  async getByField(field: string): Promise<Company[]> {
    try {
      const q = query(collection(db, "companies"), where("field", "==", field), orderBy("createdAt", "desc"))
      const querySnapshot = await getDocs(q)
      return querySnapshot.docs.map(
        (doc) =>
          ({
            id: doc.id,
            ...doc.data(),
          }) as Company,
      )
    } catch (error) {
      console.error("Error fetching companies by field:", error)
      throw error
    }
  },

  // Get companies by location
  async getByLocation(location: string): Promise<Company[]> {
    try {
      const q = query(collection(db, "companies"), where("location", "==", location), orderBy("createdAt", "desc"))
      const querySnapshot = await getDocs(q)
      return querySnapshot.docs.map(
        (doc) =>
          ({
            id: doc.id,
            ...doc.data(),
          }) as Company,
      )
    } catch (error) {
      console.error("Error fetching companies by location:", error)
      throw error
    }
  },

  // Get single company
  async getById(id: string): Promise<Company | null> {
    try {
      const docRef = doc(db, "companies", id)
      const docSnap = await getDoc(docRef)

      if (docSnap.exists()) {
        return {
          id: docSnap.id,
          ...docSnap.data(),
        } as Company
      }
      return null
    } catch (error) {
      console.error("Error fetching company:", error)
      throw error
    }
  },

  // Add new company (admin function)
  async add(companyData: Omit<Company, "id" | "createdAt" | "updatedAt">): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, "companies"), {
        ...companyData,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
      return docRef.id
    } catch (error) {
      console.error("Error adding company:", error)
      throw error
    }
  },
}

// User Profile Database Functions
export const userProfileDB = {
  // Create user profile
  async create(profileData: Omit<UserProfile, "createdAt" | "updatedAt">): Promise<void> {
    try {
      await updateDoc(doc(db, "users", profileData.uid), {
        ...profileData,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
    } catch (error) {
      console.error("Error creating user profile:", error)
      throw error
    }
  },

  // Get user profile
  async get(uid: string): Promise<UserProfile | null> {
    try {
      const docRef = doc(db, "users", uid)
      const docSnap = await getDoc(docRef)

      if (docSnap.exists()) {
        return docSnap.data() as UserProfile
      }
      return null
    } catch (error) {
      console.error("Error fetching user profile:", error)
      throw error
    }
  },

  // Update user profile
  async update(uid: string, updates: Partial<UserProfile>): Promise<void> {
    try {
      await updateDoc(doc(db, "users", uid), {
        ...updates,
        updatedAt: Timestamp.now(),
      })
    } catch (error) {
      console.error("Error updating user profile:", error)
      throw error
    }
  },

  // Add bookmark
  async addBookmark(uid: string, companyId: string): Promise<void> {
    try {
      await updateDoc(doc(db, "users", uid), {
        bookmarkedCompanies: arrayUnion(companyId),
        updatedAt: Timestamp.now(),
      })
    } catch (error) {
      console.error("Error adding bookmark:", error)
      throw error
    }
  },

  // Remove bookmark
  async removeBookmark(uid: string, companyId: string): Promise<void> {
    try {
      await updateDoc(doc(db, "users", uid), {
        bookmarkedCompanies: arrayRemove(companyId),
        updatedAt: Timestamp.now(),
      })
    } catch (error) {
      console.error("Error removing bookmark:", error)
      throw error
    }
  },

  // Get bookmarked companies
  async getBookmarkedCompanies(uid: string): Promise<Company[]> {
    try {
      const profile = await this.get(uid)
      if (!profile || !profile.bookmarkedCompanies.length) {
        return []
      }

      const companies: Company[] = []
      for (const companyId of profile.bookmarkedCompanies) {
        const company = await companiesDB.getById(companyId)
        if (company) {
          companies.push(company)
        }
      }
      return companies
    } catch (error) {
      console.error("Error fetching bookmarked companies:", error)
      throw error
    }
  },
}

// Applications Database Functions
export const applicationsDB = {
  // Create application
  async create(applicationData: Omit<Application, "id" | "appliedDate" | "lastUpdated">): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, "applications"), {
        ...applicationData,
        appliedDate: Timestamp.now(),
        lastUpdated: Timestamp.now(),
      })
      return docRef.id
    } catch (error) {
      console.error("Error creating application:", error)
      throw error
    }
  },

  // Get user applications
  async getUserApplications(userId: string): Promise<Application[]> {
    try {
      const q = query(collection(db, "applications"), where("userId", "==", userId), orderBy("appliedDate", "desc"))
      const querySnapshot = await getDocs(q)
      return querySnapshot.docs.map(
        (doc) =>
          ({
            id: doc.id,
            ...doc.data(),
          }) as Application,
      )
    } catch (error) {
      console.error("Error fetching user applications:", error)
      throw error
    }
  },

  // Update application status
  async updateStatus(applicationId: string, status: Application["status"], notes?: string): Promise<void> {
    try {
      await updateDoc(doc(db, "applications", applicationId), {
        status,
        notes,
        lastUpdated: Timestamp.now(),
      })
    } catch (error) {
      console.error("Error updating application status:", error)
      throw error
    }
  },
}

// Real-time listeners
export const realtimeListeners = {
  // Listen to companies changes
  onCompaniesChange(callback: (companies: Company[]) => void) {
    return onSnapshot(query(collection(db, "companies"), orderBy("createdAt", "desc")), (snapshot) => {
      const companies = snapshot.docs.map(
        (doc) =>
          ({
            id: doc.id,
            ...doc.data(),
          }) as Company,
      )
      callback(companies)
    })
  },

  // Listen to user profile changes
  onUserProfileChange(uid: string, callback: (profile: UserProfile | null) => void) {
    return onSnapshot(doc(db, "users", uid), (doc) => {
      if (doc.exists()) {
        callback(doc.data() as UserProfile)
      } else {
        callback(null)
      }
    })
  },
}
